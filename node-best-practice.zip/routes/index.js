const Company = require ('../controllers/companies');
const User = require ('../controllers/user.controller');
const Course = require('../controllers/course.controller');
const Joining = require('../controllers/joining.controller');
const Fee = require('../controllers/fees.controller');
const Discount = require('../controllers/discounts.controller');
const verify = require('../middleware/auth').verifyToken;
module.exports = app => {
  app.get ('/api/all', verify, Company.findAll);
  app.get ('/api/find/:name', Company.findOne);
  app.post ('/api/insert', Company.create);
  app.post ('/api/insert2', Company.create2);
  app.get ('/api/report',verify, Company.report);
  app.post ('/api/user', User.create);
  app.get ('/api/users',  User.getUsers);
  app.post ('/api/login', User.getUser);
  app.post('/api/course', Course.Create);
  app.post('/api/coursereg',Joining.Create);
  app.get('/api/getcourses', Joining.Find);
  app.post('/api/fee', Fee.create);
  app.post('/api/discount',Discount.Create);
};

